#include "sqrt.h"
#include "gtest/gtest.h"

TEST(SQRTest, Zero) {
	EXPECT_EQ(0, sqrt(0));
}

TEST(SQRTest, Positive) {
	EXPECT_EQ(100, sqrt(10000));
	EXPECT_EQ(1000, sqrt(1000009));
	EXPECT_EQ(99, sqrt(9810));
}

TEST(SQRTest, Negative) {
	int i=-1;
	int m=0;
	EXPECT_EQ(m, sqrt(i));
}

TEST(GTest, True) {
	EXPECT_EQ(10, sqrt(100));
}
