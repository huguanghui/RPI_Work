#!/bin/sh
names:=a b c d
files:=$(foreach n,$(names),$(n).o)
echo $(files)
