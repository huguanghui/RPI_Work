#include "hash_test.h"

WebsHash actionTable = -1;

/*
    Define a function in the "action" map space
 */
int websDefineAction(char *name, void *fn)
{
    assert(name && *name);
    assert(fn);

    if (fn == NULL) {
        return -1;
    }
    hashEnter(actionTable, (char*) name, valueSymbol(fn), 0);
    return 0;
}


void closeAction()
{
    if (actionTable != -1) {
        hashFree(actionTable);
        actionTable = -1;
    }
}


void websActionOpen()
{
    actionTable = hashCreate(WEBS_HASH_INIT);
    //websDefineHandler("action", 0, actionHandler, closeAction, 0);
}