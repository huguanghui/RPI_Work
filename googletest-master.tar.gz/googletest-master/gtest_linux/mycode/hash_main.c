#include "hash_test.h"

const struct soap_code_map test[] =
{
	{(LONG64)1, "test_1"},
	{(LONG64)2, "test_2"},
	{(LONG64)3, "test_3"},
	{(LONG64)0, NULL},
};

int main(int argc, char **argv)
{
	int iRet = 0;
	WebsKey *key = NULL;
	TestAction fn;

	websRuntimeOpen();
	websActionOpen();

	PRINT_Y("Hash:%d", actionTable);

	int b = (int)soap_code_int(test, "test_5", -3);
	PRINT_Y("B:%d", b);

	PRINT_Y("Str:%s", soap_code_str(test, (long)5));

	websDefineAction((char*)"abc_1", fun_1);
	websDefineAction((char*)"abc_2", fun_2);
	websDefineAction((char*)"abc_3", fun_3);

	PRINT_Y("ID:%d", iRet);
	PRINT_Y("Char:%d", sizeof(char));
	key = hashLookup(actionTable, "abc_1");
	if (key)
	{
		fn = (TestAction) key->content.value.symbol;
		if (fn)
		{
			(*fn)();
		}
	}
	else
	{
		PRINT_Y("Can't Lookup!");
	}

	closeAction();
	websRuntimeClose();

	return iRet;
}