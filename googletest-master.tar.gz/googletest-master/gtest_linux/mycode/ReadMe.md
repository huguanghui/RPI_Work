[TOC]

---

# hash的功能主要是从goahead的源码中移植而来.

# 