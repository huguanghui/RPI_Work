#ifndef HASH_TEST__H
# define HASH_TEST__H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
//#define NDEBUG
#include <assert.h>

#define PRINT_Y(x...) do{printf("\033[33m");printf("[%s:%d]", __FUNCTION__, __LINE__);printf(x);printf("\033[0m\n");}while(0)

# define LONG64 long long

#ifndef BITSPERBYTE
    #define BITSPERBYTE     ((int) (8 * sizeof(char)))
#endif

#ifndef BITS
    #define BITS(type)      ((int) (BITSPERBYTE * (int) sizeof(type)))
#endif

#define WEBS_SMALL_HASH     31          /**< General small hash size */
#define WEBS_HASH_INIT          67          /* Hash size for form table */

typedef ssize_t ssize;
/************************************* WebsValue ******************************/
/**
    Value types.
 */
typedef enum WebsType {
    undefined   = 0,
    byteint     = 1,
    shortint    = 2,
    integer     = 3,
    hex         = 4,
    percent     = 5,
    octal       = 6,
    big         = 7,
    flag        = 8,
    floating    = 9,
    string      = 10,
    bytes       = 11,
    symbol      = 12,
    errmsg      = 13
} WebsType;

/**
    System native time type. This is the time in seconds.
    This may be 32 or 64 bits and may be signed or unsigned on some systems.
 */
typedef time_t WebsTime;

/**
    Value union to store primitive value types
 */
typedef struct WebsValue {
    union {
        char    flag;
        char    byteint;
        short   shortint;
        char    percent;
        long    integer;
        long    hex;
        long    octal;
        long    big[2];
#if ME_FLOAT
        double  floating;
#endif
        char    *string;
        char    *bytes;
        char    *errmsg;
        void    *symbol;
    } value;
    WebsType    type;
    uint        valid       : 8;
    uint        allocated   : 8;        /* String was allocated */
} WebsValue;

/**
    The value is a numeric type
 */
#define value_numeric(t)    (t >= byteint && t <= big)

/**
    The value is a string type
 */
#define value_str(t)        (t >= string && t <= bytes)

/**
    The value is valid supported type
 */
#define value_ok(t)         (t > undefined && t <= symbol)

/**
    Allocate strings using malloc
 */
#define VALUE_ALLOCATE      0x1

/**
    Create an integer value
    @param value Integer long value
    @return Value object containing the integer
    @stability Stable
 */
WebsValue valueInteger(long value);

/**
    Create an string value
    @param value String long value
    @param flags Set to VALUE_ALLOCATE to store a copy of the string reference
    @return Value object containing the string
    @stability Stable
 */
WebsValue valueString(char *value, int flags);

/**
    Create an symbol value containing an object reference
    @param value Value reference
    @return Value object containing the symbol reference
    @stability Stable
 */
WebsValue valueSymbol(void *value);

/**
    Free any allocated string in a value
    @param value Value object
    @stability Stable
 */
void valueFree(WebsValue *value);

/******************************* Hash Table *********************************/
/**
    Hash table entry structure.
    @description The hash structure supports growable hash tables with high performance, collision resistant hashes.
    Each hash entry has a descriptor entry. This is used to manage the hash table link chains.
    @see hashCreate hashFree hashLookup hashEnter hashDelete hashWalk hashFirst hashNext
    @defgroup WebsHash WebsHash
    @stability Stable
 */
typedef struct WebsKey {
    struct WebsKey  *forw;                  /* Pointer to next hash list */
    WebsValue       name;                   /* Name of symbol */
    WebsValue       content;                /* Value of symbol */
    int             arg;                    /* Parameter value */
    int             bucket;                 /* Bucket index */
} WebsKey;

/**
    Hash table ID returned by hashCreate
 */
typedef int WebsHash;                       /* Returned by symCreate */

/**
    Create a hash table
    @param size Minimum size of the hash index
    @return Hash table ID. Negative if the hash cannot be created.
    @ingroup WebsHash
    @stability Stable
 */
WebsHash hashCreate(int size);

/**
    Free a hash table
    @param id Hash table id returned by hashCreate
    @ingroup WebsHash
    @stability Stable
 */
void hashFree(WebsHash id);

/**
    Lookup a name in the hash table
    @param id Hash table id returned by hashCreate
    @param name Key name to search for
    @return Reference to the WebKey object storing the key and value
    @ingroup WebsHash
    @stability Stable
 */
WebsKey *hashLookup(WebsHash id, char *name);

/**
    Lookup a name in the hash table and return a symbol reference
    @param sd Hash table id returned by hashCreate
    @param name Key name to search for
    @return Reference to the symbole
    @ingroup WebsHash
    @stability Evolving
 */
void *hashLookupSymbol(WebsHash sd, char *name);

/**
    Enter a new key and value into the hash table
    @param id Hash table id returned by hashCreate
    @param name Key name to create
    @param value Key value to enter
    @param arg Optional extra argument to store with the value
    @return Reference to the WebKey object storing the key and value
    @ingroup WebsHash
    @stability Stable
 */
WebsKey *hashEnter(WebsHash id, char *name, WebsValue value, int arg);

/**
    Delete a key by name
    @param id Hash table id returned by hashCreate
    @param name Key name to delete
    @return Zero if the delete was successful. Otherwise -1 if the key was not found.
    @ingroup WebsHash
    @stability Stable
 */
int hashDelete(WebsHash id, char *name);

/**
    Start walking the hash keys by returning the first key entry in the hash
    @param id Hash table id returned by hashCreate
    @return Reference to the first WebKey object. Return null if there are no keys in the hash.
    @ingroup WebsHash
    @stability Stable
 */
WebsKey *hashFirst(WebsHash id);

/**
    Continue walking the hash keys by returning the next key entry in the hash
    @param id Hash table id returned by hashCreate
    @param last Reference to a WebsKey to hold the current traversal key state.
    @return Reference to the next WebKey object. Returns null if no more keys exist to be traversed.
    @ingroup WebsHash
    @stability Stable
 */
WebsKey *hashNext(WebsHash id, WebsKey *last);

/**
    Allocate a handle from a map
    @param map Reference to a location holding the map reference. On the first call, the map is allocated.
    @return Integer handle index. Otherwise return -1 on allocation errors.
    @ingroup WebsRuntime
    @stability Stable
 */
int wallocHandle(void *map);

/**
    Free a handle in the map
    @param map Reference to a location to hold the map reference.
    @param handle Handle to free in the map.
    @return Integer handle index. Otherwise return -1 on allocation errors.
    @ingroup WebsRuntime
    @stability Stable
 */
int wfreeHandle(void *map, int handle);

/**
    Clone a string
    @description Copy a string into a newly allocated block.
    @param str Pointer to the block to duplicate.
    @return Returns a newly allocated string.
    @ingroup WebsRuntime
    @stability Stable
 */
char *sclone(char *str);

/**
    Allocate a block of the requested size
    @param size Memory size required
    @return A reference to the allocated block
    @ingroup WebsAlloc
    @stability Stable
 */
void *walloc(ssize size);

/**
    Free an allocated block of memory
    @param blk Reference to the memory block to free.
    @ingroup WebsAlloc
    @stability Stable
 */
void wfree(void *blk);

/**
    Reallocate a block of memory and grow its size
    @description If the new size is larger than the existing block, a new block will be allocated and the old data
        will be copied to the new block.
    @param blk Original block reference
    @param newsize Size of the new block.
    @return Reference to the new memory block
    @ingroup WebsAlloc
    @stability Stable
 */
void *wrealloc(void *blk, ssize newsize);

typedef void (*WebsMemNotifier)(ssize size);

void websRuntimeClose();

/**
    Open the runtime code.
    @description Called from websOpen
    @return Zero if successful
    @ingroup Webs
    @internal
 */
int websRuntimeOpen();

// UserDefine
int fun_1();

int fun_2();

int fun_3();

/**
    Action callback
    @param wp Webs request object
    @ingroup Webs
    @stability Stable
 */
typedef void (*TestAction)();

/**
    Define an action callback for use with the action handler.
    @description The action handler binds a C function to a URI under "/action".
    @param name URI path suffix. This suffix is added to "/action" to form the bound URI path.
    @param fun Callback function. The signature is void (*WebsAction)(Webs *wp);
    @return Zero if successful, otherwise -1.
    @ingroup Webs
    @stability Stable
 */
int websDefineAction(char *name, void *fun);

/**
    Open the action handler
    @ingroup Webs
    @stability Stable
 */
void websActionOpen();

void closeAction();

struct soap_code_map
{ 
  LONG64 code;
  const char *string;
};

const struct soap_code_map* soap_code(const struct soap_code_map *code_map, const char *str);
LONG64 soap_code_int(const struct soap_code_map *code_map, const char *str, LONG64 other);
const char* soap_code_str(const struct soap_code_map *code_map, long code);
//LONG64 soap_code_bits(const struct soap_code_map *code_map, const char *str);

extern WebsHash actionTable;

#endif