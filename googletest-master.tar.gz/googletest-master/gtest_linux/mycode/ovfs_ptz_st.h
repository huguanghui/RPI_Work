#ifndef OVFS_PTZ_ST__H
#define OVFS_PTZ_ST__H

#define NAMELEN (32)
#define FUNCLEN (64)

typedef struct OVFS_PTZ_INPARAM_S{
	int method;
	char action[FUNCLEN];
	char query[FUNCLEN];
}OVFS_PTZ_INPARAM_T;

#endif