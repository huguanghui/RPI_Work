/*
	mtom-test.h
*/

#import "soap12.h"
#import "xop.h"
#import "xmime5.h"

//gsoap m service name: mtom_test
//gsoap m service namespace: http://www.genivia.com/wsdl/mtom_test.wsdl

//gsoap x schema namespace:  http://www.genivia.com/schemas/mtom_test.xsd
//gsoap x schema elementForm: qualified

struct xsd__base64Binary
{ unsigned char *__ptr;
  int __size;
};

//gsoap x schema type-documentation: DataType a union of an MIME attachment or a base64 binary data type
struct x__DataType
{ int __union;
  union x__data
  { _xop__Include xop__Include;
    struct xsd__base64Binary base64;
  } choice;
  @char *xmime5__contentType;
};

//gsoap x schema type-documentation: WrapperType wraps a sequence of data elements with MIME attachments or base64  binary data
struct x__WrapperType
{ int __size;
  struct x__DataType *Data;
};

//gsoap m service method-input-mime-type: EchoTestSingle text/xml
//gsoap m service method-output-mime-type: EchoTestSingle text/xml

//gsoap m service method-documentation: EchoTestSingle echo a single MIME attachment or base64 binary data element
int m__EchoTestSingle(
  struct x__DataType *x__Data,
  struct m__EchoTestSingleResponse
  { struct x__DataType *x__Data;
  }*
);

//gsoap m service method-mime-type: EchoTestMultiple */*
//gsoap m service method-mime-type: EchoTestMultiple */*

//gsoap m service method-documentation: EchoTestMultiple echo a sequence of MIME attachments or base64 binary data elements
int m__EchoTestMultiple(
  struct x__WrapperType *x__EchoTest,
  struct m__EchoTestMultipleResponse
  { struct x__WrapperType *x__EchoTest;
  }*
);
