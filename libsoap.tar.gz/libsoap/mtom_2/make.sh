#!/bin/sh
soapcpp2 -cL -I/home/hugh/gsoap -I/home/hugh/gsoap/import -I/home/hugh/gsoap/custom mtom-test.h
